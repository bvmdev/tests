# electron-angularjs-sqlite
Um aplicativo simples usando AngularJS, Sqlite, Electron e Bootstrap
<br>
Exemplo para tutorial no [Clube dos Geeks](http://clubedosgeeks.com.br/programacao/node-js/criando-aplicativo-com-electron-gerando-executavel)
## Usando
#### 1 - Clone este repositório no seu computador:
``` 
git clone https://github.com/ClubeDosGeeksCoding/electron-angularjs-sqlite.git
```
#### 2 - Instale as dependências
```
npm install
```
#### 3 - Execute o aplicativo
```
npm start
```
#### 4 - Gerando Executável<br>
[Veja aqui](http://clubedosgeeks.com.br/programacao/node-js/criando-aplicativo-com-electron-gerando-executavel#executar) como criar o executável.
