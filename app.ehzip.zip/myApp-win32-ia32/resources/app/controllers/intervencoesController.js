"USE STRICT";
app.controller("intervencoesController", function($scope, $location, dbService){

	$scope.status = ["TO DO", "DOING", "WAITING", "DONE"];
	$scope.sistema = ["ON6", "AH5", "OO3", "CX7","XD","VJ","VX","OK2","OK4","OK5","Y9","Y6","PL","OT5","LD"];

	//Listando
	$scope.lista = function(){
		dbService.runAsync("SELECT * FROM intervencoes", function(data){
			$scope.interv = data;
		});
	}

	//Salvando
	$scope.salvar = function(){
		if($scope.int.id){
			//Editar
		
			var id = $scope.int.id;
			delete $scope.int.id;
			delete $scope.int.$$hashKey; //Apaga elemento $$hashKey do objeto
			dbService.update('intervencoes', $scope.int, {id: id}); //entidade, dados, where
		}else{
			//nova
			dbService.insert('intervencoes', $scope.int); // entidade, dados
		}
		$scope.interv = {};
		$scope.lista();
		$('#modalInterv').modal('hide');
	}

	//Abrindo para editar
	$scope.editar = function(dados){
		$scope.int = dados;
		$('#modalInterv').modal('show');
	}

	//Abrindo Descrição
	$scope.showDescricao = function(dados){

		$scope.int = dados;
		$('#modalIntervDesc').modal('show');
	}

	//Excluindo
	$scope.excluir = function(dados){

		if(confirm("Deseja realmente apagar o cadastro de "+dados.id+"?")){
			//dbService.delete('intervencoes', {id: dados.id});
			dbService.run("DELETE FROM intervencoes WHERE id = ?;",[dados.id]);
			$scope.lista();
		}
	}
});